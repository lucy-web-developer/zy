import React, {  useContext, useReducer } from 'react'
import reducer from '../reducer/mapData_reducer'

const initialState = {
  flag:true,
  addressOutContext:[],
  
}

const AppContext = React.createContext()
export const AppProvider = ({ children }) => {
  const [state,dispatch]=useReducer(reducer,initialState)
  const add_Item=(addressOut)=>{
    console.log('add item',addressOut)
    dispatch({type:"ADD_ITEM",payload:addressOut})
  }

  const removeItem=(selectedRowKeys,addressOut)=>{
    
    console.log(selectedRowKeys)
    dispatch({type:"REMOVE_ITEM",payload:{deleteKey:selectedRowKeys,address:addressOut}})
  }
  const flag_signal=()=>{
    dispatch({type:"FLAG_SIGNAL"})
  }
  

  return (
    <AppContext.Provider value={{
      ...state,      
      removeItem,      
      add_Item,
      flag_signal,
    }}>{children}</AppContext.Provider>
  )
}
// make sure use
export const useGlobalContext = () => {
  return useContext(AppContext)
}
