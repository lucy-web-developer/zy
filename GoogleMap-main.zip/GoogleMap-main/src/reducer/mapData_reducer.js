
const cart_reducer = (state, action) => {
   const {address, deleteKey}=action.payload;
    const newItems=[];
   if(action.type==="REMOVE_ITEM"){ 
    for(let i=0;i<address.length;i++){
        console.log(address.length);
        let flag=true;
         for(let j=0;j<deleteKey.length;j++){
          
           if(i==deleteKey[j]){
                console.log('deleteItemNumer is ',i );
                flag=false;
                break;
           }
        }
        if(flag) {
            newItems.push(address[i]);
        }
    } 
    return {...state, addressOutContext:newItems,flag:false}
   }
if(action.type==="FLAG_SIGNAL"){
    return {...state, flag:true}
}

   if(action.type==="ADD_ITEM"){ 
   
    return {...state, addressOutContext:[...state.addressOutContext,action.payload]}
   }
  
  throw new Error(`No Matching "${action.type}" - action type`)
}

export default cart_reducer
