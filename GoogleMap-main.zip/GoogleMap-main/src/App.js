import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import  SharedLayout  from './SharedLayout/SharedLayout'
import Error from './pages/ErrorPage'
import Map from './pages/Map'

// import Table from './pages/Table'
function App() {
  return (   
      <Router>                
        <Routes >
          <Route path='/' element={<SharedLayout/>} >
            <Route index element={<Map/>}/>
                       
          </Route>
                    
          <Route path='*' element={<Error/>} />
        </Routes>
        
      </Router>
          
    )
}

export default App
