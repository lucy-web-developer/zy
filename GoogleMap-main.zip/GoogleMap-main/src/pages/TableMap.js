import { Table } from 'antd';
import React, { useEffect,useState } from 'react';
import { useGlobalContext } from '../context/mapData_context'

const App = ({addressOut}) => {
  const [tableData,setTableDate]=useState([]);
   const {removeItem,flag,addressOutContext,add_Item}=useGlobalContext();
  //  useEffect(()=>{
  //   add_Item(addressOut);
  // },[])
    // const [flag, setFlag]=useState(true);
     console.log('addressOutContext',addressOutContext.flat())
    console.log('addressOut',addressOut)
     const newaddressOutContext=addressOutContext.flat().filter((item)=>item!==[]);
    const columns = [
  {
    title: 'Number',
    dataIndex: 'number',
  },
  {
    title: 'Address',
    dataIndex: 'address',
  },
  {
    title: 'Time',
    dataIndex: 'time',
  },
 
];
var data = [];
if(flag){
  data=[]
  for (let i = 0; i<addressOut.length ; i++) {
    const name=addressOut[i].address;
    const time=addressOut[i].time;
   
  data.push({
    key: i,
    number: `${i+1}`,
    address: `${name}`,
    time: `${time}`,
   
  });
}
}else{
  data=[]
  for (let i = 0; i<newaddressOutContext.length ; i++) {
    const name=newaddressOutContext[i].address;
    const time=newaddressOutContext[i].time;
   
  data.push({
    key: i,
    number: `${i+1}`,
    address: `${name}`,
    time: `${time}`,
   
  });
}
}





  const [selectedRowKeys, setSelectedRowKeys] = useState([]);

  const onSelectChange = (newSelectedRowKeys) => {
    console.log('selectedRowKeys changed: ', selectedRowKeys);
    setSelectedRowKeys(newSelectedRowKeys);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
    selections: [
      Table.SELECTION_ALL,
      Table.SELECTION_INVERT,
      Table.SELECTION_NONE,
      {
        key: 'odd',
        text: 'Select Odd Row',
        onSelect: (changableRowKeys) => {
          let newSelectedRowKeys = [];
          newSelectedRowKeys = changableRowKeys.filter((_, index) => {
            if (index % 2 !== 0) {
              return false;
            }

            return true;
          });
          setSelectedRowKeys(newSelectedRowKeys);
        },
      },
      {
        key: 'even',
        text: 'Select Even Row',
        onSelect: (changableRowKeys) => {
          let newSelectedRowKeys = [];
          newSelectedRowKeys = changableRowKeys.filter((_, index) => {
            if (index % 2 !== 0) {
              return true;
            }

            return false;
          });
          setSelectedRowKeys(newSelectedRowKeys);
        },
      },
    ],
  };

// function removeItem(b,a){
//  const newItems=[];
   
//     for(let i=0;i<a.length;i++){
        
//         let flag=true;
//          for(let j=0;j<b.length;j++){
          
//            if(i==b[j]){
//                 console.log('deleteItemNumer is ',i );
//                 flag=false;
//                 break;
//            }
//         }
//         if(flag) {
//             newItems.push(a[i]);
//         }
//     } 

// }


  return <>
  <button className='delete' onClick={flag?()=>{
    console.log(selectedRowKeys)
    removeItem(selectedRowKeys,addressOut)}:
    ()=>{
    
    removeItem(selectedRowKeys,addressOutContext)}
    }>Delete</button>
  <Table className='table' rowSelection={rowSelection} columns={columns} dataSource={data} />

</>
};

export default App;  