import React from "react";
import {
  GoogleMap,
  useLoadScript,
  Marker,
  InfoWindow,
} from "@react-google-maps/api";

import { formatRelative} from "date-fns";
import moment from 'moment'
import "@reach/combobox/styles.css";
import { useState } from "react";
import Locate from '../components/Locate'
import Search from '../components/Search'
import { useGlobalContext } from '../context/mapData_context'


const libraries = ["places"];
const mapContainerStyle = {
  margin:"100px auto",  
  width: "80vw",
  height: "500px",
};
const options = {
  disableDefaultUI: true,
  zoomControl: true,
};
const center = {
  lat: 43.8737,
  lng: -79.2602,
  
};

export default function App() {
  const {addressOutContext,flag}=useGlobalContext();

  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
    libraries,
  });
  const [markers, setMarkers] = useState([]);
  const [selected, setSelected] = useState(null); 
  const [home,setHome] = useState(false);
  const [lat,setLat]=useState(43.4737);
  const [lng,setLng]=useState(-79.2602);
  
  const mapRef = React.useRef();
  const onMapLoad = React.useCallback((map) => {
    mapRef.current = map;
  }, []);

  const panTo = React.useCallback(({ lat, lng }) => {
    
    mapRef.current.panTo({ lat, lng });
    mapRef.current.setZoom(14);
    
    setMarkers((current) => [
      ...current,
      {
        lat: lat,
        lng: lng,
        address:'',
        time: new Date(),
      },
    ]);
  }, []);

  const panTo1 = React.useCallback(({ lat, lng,e }) => {
    console.log(lat,lng)
    mapRef.current.panTo({ lat, lng });
    mapRef.current.setZoom(16);
    setLat(lat);
    setLng(lng)
    setHome(true);
    setTimeout(()=>{
      setHome(false);
    },5000)
  }, []);

  if (loadError) return "Error";
  if (!isLoaded) return "Loading...";

  return (
    <div>            
      <Locate panTo1={panTo1} />
      <Search panTo={panTo} markers={markers} />
      <GoogleMap
        id="map"
        mapContainerStyle={mapContainerStyle}
        zoom={8}
        center={center}
        options={options}
        onLoad={onMapLoad}
      >
        {console.log(markers)}
        {flag?markers.map((marker) => (
          <Marker
            key={`${marker.lat}-${marker.lng}`}            
            position={{ lat: marker.lat, lng: marker.lng }}
            onClick={() => {
              setSelected(marker);
            }}

          />
        )):
        addressOutContext.map((marker) => (
          <Marker
            key={`${marker.lat}-${marker.lng}`}            
            position={{ lat: marker.lat, lng: marker.lng }}
            onClick={() => {
              setSelected(marker);
            }}

          />
        ))
        
        }
        {home?(
          <Marker
            key={`${lat}-${lng}`}
            position={{ lat: lat, lng: lng }}
            icon={{
              url: `/home1.png`,
              origin: new window.google.maps.Point(0, 0),
              anchor: new window.google.maps.Point(15, 15),
              scaledSize: new window.google.maps.Size(30, 38),
            }}
       />
        ): null
        }
              
      {selected ? (
          <InfoWindow
            position={{ lat: selected.lat+0.001001, lng: selected.lng  }}
            onCloseClick={() => {
              setSelected(null);
            }}
          >
            
            <div>              
            <p>Search {formatRelative(selected.time, new Date())}  <span>({moment(selected.time).format("MMM Do YY")})</span>
                </p>
            </div>
          </InfoWindow>
        ) : null}
      </GoogleMap>
    </div>
  );
}
