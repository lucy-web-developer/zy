import React from "react";
import {
  GoogleMap,
  useLoadScript,
  Marker,
  InfoWindow,
} from "@react-google-maps/api";
// import usePlacesAutocomplete, {
//   getGeocode,
//   getLatLng,
// } from "use-places-autocomplete";
// import {
//   Combobox,
//   ComboboxInput,
//   ComboboxPopover,
//   ComboboxList,
//   ComboboxOption,
// } from "@reach/combobox";
import { formatRelative} from "date-fns";
import moment from 'moment'
import "@reach/combobox/styles.css";
// import { useEffect } from "react";
import { useState } from "react";
// import TableMap from './TableMap'
import Locate from '../components/Locate'
import Search from '../components/Search'
import { useGlobalContext } from '../context/mapData_context'


const libraries = ["places"];
const mapContainerStyle = {
  margin:"100px auto",  
  width: "80vw",
  height: "500px",
};
const options = {
  disableDefaultUI: true,
  zoomControl: true,
};
const center = {
  lat: 43.6532,
  lng: -79.3832,
  
};

export default function App() {
  const {addressOut}=useGlobalContext();

  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
    libraries,
  });
  const [markers, setMarkers] = useState([]);
  const [selected, setSelected] = useState(null); 
  // const onMapClick = React.useCallback((e) => {
  //   setMarkers((current) => [
  //     ...current,
  //     {
  //       lat: e.latLng.lat(),
  //       lng: e.latLng.lng(),
  //       time: new Date(),
  //     },
  //   ]);   
  // }, []);

  const mapRef = React.useRef();
  const onMapLoad = React.useCallback((map) => {
    mapRef.current = map;
  }, []);

  const panTo = React.useCallback(({ lat, lng,e }) => {
    console.log(e)
    mapRef.current.panTo({ lat, lng });
    mapRef.current.setZoom(14);

    setMarkers((current) => [
      ...current,
      {
        lat: lat,
        lng: lng,
        time: new Date(),
      },
    ]);
  }, []);

  if (loadError) return "Error";
  if (!isLoaded) return "Loading...";

  return (
    <div>            
      <Locate panTo={panTo} />
      <Search panTo={panTo} />
      <GoogleMap
        id="map"
        mapContainerStyle={mapContainerStyle}
        zoom={8}
        center={center}
        options={options}
        // onClick={onMapClick} //extend function jjx note
        onLoad={onMapLoad}
      >
        
        {markers.map((marker) => (
          <Marker
            key={`${marker.lat}-${marker.lng}`}
            // draggable={true}                    extend drag function
            // onDragEnd={ onMarkerDragEnd }
            position={{ lat: marker.lat, lng: marker.lng }}
            onClick={() => {
              setSelected(marker);
            }}

          />
        ))}
        
              
      {selected ? (
          <InfoWindow
            position={{ lat: selected.lat+0.001001, lng: selected.lng  }}
            onCloseClick={() => {
              setSelected(null);
            }}
          >
            
            <div>              
            <p>Search {formatRelative(selected.time, new Date())}  <span>({moment(selected.time).format("MMM Do YY")})</span>
                </p>
            </div>
          </InfoWindow>
        ) : null}
      </GoogleMap>
    </div>
  );
}
