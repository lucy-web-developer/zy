import React from 'react'
import styled from 'styled-components'
import { NavLink } from 'react-router-dom'
import { links } from '../data/constants'
const Nav = () => {

  return <NavContainer>
    <div className="nav-center">
            
        <div className="nav-links">
          {links.map(link=>{
            return(
            <p key={link.id}>              
              <NavLink to={link.url} className={({isActive})=>isActive?'link active':'link'}>{link.text}</NavLink>
            </p>
            )
          })}        
        </div>
       
    </div>
    </NavContainer>
}

const NavContainer = styled.nav`
  background: white;
  height: 5rem;
  display: flex;
  align-items: center;
  border-bottom: 2px solid var(--primaryColor);
  box-shadow: var(--lightShadow);

  .nav-center {
    width: 90vw;
    margin: 0 auto;
    max-width: var(--max-width);
  }

.nav-links {
    display: flex;
    justify-content: center;
    
    .link {            
        margin: 0 0.5rem;        
    }      
    .active {
    color: red;
    }      
    a {
        list-style-type: none
        display: inline-block;
        color: var(--clr-grey-3);
        font-size: 1.2rem;
        text-transform: capitalize;            
        padding: 0.5rem;
        
    }
}

  
`

export default Nav
