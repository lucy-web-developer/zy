import React from 'react'
import usePlacesAutocomplete, {
  getGeocode,
  getLatLng,
} from "use-places-autocomplete";
import {
  Combobox,
  ComboboxInput,
  ComboboxPopover,
  ComboboxList,
  ComboboxOption,
} from "@reach/combobox";
// import { formatRelative} from "date-fns";
// import moment from 'moment'
import "@reach/combobox/styles.css";
import { useEffect } from "react";
import { useState } from "react";
import TableMap from '../pages/TableMap'

import { useGlobalContext } from '../context/mapData_context'

function Search({ panTo, markers }) {

  console.log(markers)
   const {add_Item,flag_signal,flag}=useGlobalContext();
  const [addressOut,setAddressOut]=useState([]);
  const {
    ready,
    value,
    suggestions: { status, data },
    setValue,
    
    clearSuggestions,
  } = usePlacesAutocomplete({
    requestOptions: {
      location: { lat: () => 43.6532, lng: () => -79.3832 },
      radius: 100 * 1000,
    },
  });

  const handleInput = (e) => {
    setValue(e.target.value);
  };

  const handleSelect = async (address) => {
    
    console.log(address);
    setValue(address, false);
    clearSuggestions();

    try {
      const results = await getGeocode({ address });
      const { lat, lng } = await getLatLng(results[0]);
      console.log("setDataOutputTable",lat,lng,address)
    setAddressOut((current) => [
      ...current,
      {
        lat: lat,
        lng: lng,
        address: address,
        time: new Date(),
      },
    ])
  

      panTo({ lat, lng });
    } catch (error) {
      console.log("😱 Error: ", error);
    }
  };
  
  useEffect(() => {
    const listener = event => {
      if (event.code === "Enter" ) {        
        event.preventDefault();
        handleSelect(value);
      }
    };
    document.addEventListener("keydown", listener);
    return () => {
      document.removeEventListener("keydown", listener);
    };
  }, [value]);
//   useEffect(()=>{
//     add_Item(addressOut);
//   },[flag])

  return (<>
    <div className="search contact-form"  >
      
        <Combobox onSelect={handleSelect} >
        <ComboboxInput
          value={value}
          onChange={handleInput}
          disabled={!ready}
          className="form-input "
          placeholder="Enter a location"
        />
        <ComboboxPopover>
          <ComboboxList>
            {status === "OK" &&
              data.map(({ id, description }) => (
                
                <ComboboxOption key={id} value={description} />
              ))}
          </ComboboxList>
        </ComboboxPopover>
      </Combobox>
      
         <button className="submit-btn" type='button' onClick={()=>{handleSelect(value)}} >🔍</button>
              
         {console.log("OutputTable",addressOut)}
          
      
    </div>
    <TableMap addressOut={addressOut}/>
    </>
  );
}
export default Search