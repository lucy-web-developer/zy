import React from 'react'
import styled from 'styled-components'

import logo from '../assets/logojjx.png'
const Nav = () => {

  return <NavContainer>
    <div className="nav-center">
        <img src={logo} alt='logo'/>
        
       
    </div>
    </NavContainer>
}

const NavContainer = styled.nav`
  background: white;
  height: 5rem;
  display: flex;
  align-items: center;
  border-bottom: 2px solid var(--primaryColor);
  box-shadow: var(--lightShadow);

  .nav-center {
    width: 90vw;
    margin: 0 auto;
    max-width: var(--max-width);
    text-align:right;
  }



  
`

export default Nav
